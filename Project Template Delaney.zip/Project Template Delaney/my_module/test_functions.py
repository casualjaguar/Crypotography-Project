"""Test for my functions.

Note: because these are 'empty' functions (return None), here we just test
  that the functions execute, and return None, as expected.
"""

##
##

    
def test_all_functions():
    
    #test lower_case() function
    assert isinstance(lower_case('string'),string)
    assert no_punctuation('CAPITAL LETTERS') == 'capital letters'
    
    #test reverse() function
    assert isinstance(reverse('string',string))
    assert reverse('abcdefg') == 'gfedcba'
    
    #test my_cipher() function
    assert isinstance(my_cipher('string'),string)
    assert my_cipher('coding') == 'elfbwz'
    
    #test create_my_code() function 
    assert isinstance(create_my_code('string'),string)
    assert create_my_code('Passing tests.') == 'dgdxg hcjddbv'



                 
    